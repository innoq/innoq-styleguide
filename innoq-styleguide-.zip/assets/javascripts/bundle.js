(function () {
'use strict';

if(typeof global === "undefined" && typeof window !== "undefined") {
	window.global = window;
}

class InfoBox extends HTMLElement {
  connectedCallback () {
    this.classList.add('enhanced');
    this.setAttribute('open', 'false');
    this.contentHeight = `${this.content.clientHeight}px`;
    this.content.style.height = 0;
    this.teaser.onclick = this.toggle.bind(this);
  }

  get content () {
    return this.querySelector('.infobox__content')
  }

  get teaser () {
    return this.querySelector('.infobox__teaser')
  }

  toggle () {
    this.open = !this.open;

    if (this.open) {
      this.content.style.height = this.contentHeight;
    } else {
      this.content.style.height = 0;
    }
  }

  get open () {
    return this.getAttribute('open') === 'true'
  }

  set open (value) {
    this.setAttribute('open', value.toString());
  }
}

class MultiToggler extends HTMLElement {
  connectedCallback () {
    let targetSelector = this.getAttribute('data-target');
    this.toggleClass = this.getAttribute('data-toggle-class');
    if (targetSelector === '') {
      this.toggleTargets = undefined;
    } else {
      this.toggleTargets = Array.from(document.querySelectorAll(targetSelector));
    }
    this.onclick = this.toggle.bind(this);
    this.classList.add('enhanced');
  }

  toggle () {
    if (this.toggleTargets) {
      this.toggleTargets.forEach(
        target => target.classList.toggle(this.toggleClass)
      );
      this.toggleSelf();
    }
  }

  toggleSelf () {
    if (this.toggleTargets) {
      if (this.getAttribute('toggled') !== null) {
        this.removeAttribute('toggled');
      } else {
        this.setAttribute('toggled', '');
      }
    }
  }
}

class CheckToToggle extends HTMLElement {
  connectedCallback () {
    this.checkbox.onclick = this.toggle.bind(this);
  }

  get checkbox () {
    return this.querySelector('.check-to-toggle__checkbox')
  }

  get target () {
    const selector = this.getAttribute('target');
    return document.querySelector(selector)
  }

  toggle () {
    if (this.checkbox.checked) {
      this.target.classList.add('hidden');
    } else {
      this.target.classList.remove('hidden');
    }
  }
}

customElements.define('info-box', InfoBox);
customElements.define('multi-toggler', MultiToggler);
customElements.define('check-to-toggle', CheckToToggle);

}());
