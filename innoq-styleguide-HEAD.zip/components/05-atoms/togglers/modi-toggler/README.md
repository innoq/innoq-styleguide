Toggles a modifier on a BEM className of selected elements.
