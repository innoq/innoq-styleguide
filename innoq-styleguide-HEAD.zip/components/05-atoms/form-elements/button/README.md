Idee für Button Transitions hier: [Tympanus](http://tympanus.net/Development/CreativeButtons)
