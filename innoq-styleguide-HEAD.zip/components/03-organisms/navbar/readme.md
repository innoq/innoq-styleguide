Notizen:

- Bei Dropdowneinträgen nimmt die Dropdownkomponente den Platz des Primary-Links ein. Dieser kommt dann als erstes Element in die Dropdownkomponente

Issues:

- Firefox/macos: Anchor-Elemente lassen sich nicht durchtabben.
  - Liegt offenbar an Firefox und macos, siehe:
    https://stackoverflow.com/questions/11704828/how-to-allow-keyboard-focus-of-links-in-firefox
